import { pgTable, text, serial, timestamp, integer, real, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const scansTable = pgTable("scans", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  category: text("category").notNull(),
  subType: text("sub_type").notNull(),
  disposalInstructions: text("disposal_instructions").notNull(),
  recyclable: boolean("recyclable").notNull().default(false),
  creditsEarned: integer("credits_earned").notNull().default(10),
  confidence: real("confidence").notNull().default(0.9),
  feedbackCorrect: boolean("feedback_correct"),
  feedbackNote: text("feedback_note"),
  correctCategory: text("correct_category"),
  zone: text("zone"),
  imageDescription: text("image_description"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertScanSchema = createInsertSchema(scansTable).omit({ id: true, createdAt: true });
export type InsertScan = z.infer<typeof insertScanSchema>;
export type Scan = typeof scansTable.$inferSelect;
