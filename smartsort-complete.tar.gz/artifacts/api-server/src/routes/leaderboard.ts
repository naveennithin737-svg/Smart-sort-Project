import { Router } from "express";
import { db } from "@workspace/db";
import { usersTable, scansTable } from "@workspace/db";
import { desc, count, sum, eq } from "drizzle-orm";

const router = Router();

const BADGES = ["Eco-Novice", "Green Guardian", "Waste Warrior", "Eco-Hero", "Planet Champion"];

function getBadgeForCredits(credits: number): string {
  if (credits >= 2000) return "Planet Champion";
  if (credits >= 1000) return "Eco-Hero";
  if (credits >= 500) return "Waste Warrior";
  if (credits >= 200) return "Green Guardian";
  return "Eco-Novice";
}

router.get("/leaderboard", async (req, res): Promise<void> => {
  const limit = Math.min(Number(req.query.limit) || 10, 50);
  const users = await db.select({
    id: usersTable.id,
    name: usersTable.name,
    ecoCredits: usersTable.ecoCredits,
    totalScans: usersTable.totalScans,
  }).from(usersTable)
    .where(eq(usersTable.isAdmin, false))
    .orderBy(desc(usersTable.ecoCredits))
    .limit(limit);

  const entries = users.map((u, idx) => ({
    rank: idx + 1,
    userId: u.id,
    name: u.name,
    ecoCredits: u.ecoCredits,
    totalScans: u.totalScans,
    badge: getBadgeForCredits(u.ecoCredits),
  }));
  res.json(entries);
});

export default router;
