import { Router } from "express";
import { db } from "@workspace/db";
import { scansTable, usersTable, transactionsTable } from "@workspace/db";
import { eq, count, sum, sql, gte } from "drizzle-orm";

const router = Router();

router.get("/community/stats", async (req, res): Promise<void> => {
  const [scansCount] = await db.select({ total: count() }).from(scansTable);
  const [usersCount] = await db.select({ total: count() }).from(usersTable).where(eq(usersTable.isAdmin, false));
  const [recycled] = await db.select({ total: count() }).from(scansTable).where(eq(scansTable.recyclable, true));
  const [creditsSum] = await db.select({ total: sum(transactionsTable.amount) }).from(transactionsTable).where(eq(transactionsTable.type, "scan"));

  const totalScans = scansCount.total ?? 0;
  const totalRecycled = recycled.total ?? 0;

  const co2SavedKg = Number(totalRecycled) * 0.3;
  const plasticDivertedKg = Number(totalRecycled) * 0.15;

  const oneWeekAgo = new Date();
  oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
  const [weeklyScans] = await db.select({ total: count() }).from(scansTable).where(gte(scansTable.createdAt, oneWeekAgo));
  const weeklyCount = weeklyScans.total ?? 0;
  const weeklyGrowthPercent = totalScans > 0 ? Math.round((Number(weeklyCount) / Number(totalScans)) * 100) : 0;

  const categories = await db.select({
    category: scansTable.category,
    cnt: count(),
  }).from(scansTable).groupBy(scansTable.category).orderBy(sql`count(*) desc`).limit(1);

  res.json({
    totalScans: Number(totalScans),
    totalUsersActive: Number(usersCount.total ?? 0),
    co2SavedKg: Math.round(co2SavedKg * 10) / 10,
    plasticDivertedKg: Math.round(plasticDivertedKg * 10) / 10,
    totalCreditsEarned: Number(creditsSum.total ?? 0),
    topCategory: categories[0]?.category ?? "Plastic",
    weeklyGrowthPercent,
  });
});

export default router;
