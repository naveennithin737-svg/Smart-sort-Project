import { Router } from "express";
import { db } from "@workspace/db";
import { scansTable, usersTable } from "@workspace/db";
import { eq, desc, count, and } from "drizzle-orm";

const router = Router();

router.get("/ewaste/stats", async (_req, res): Promise<void> => {
  const [totals] = await db
    .select({ total: count() })
    .from(scansTable)
    .where(eq(scansTable.category, "E-Waste"));

  const allEwaste = await db
    .select()
    .from(scansTable)
    .where(eq(scansTable.category, "E-Waste"))
    .orderBy(desc(scansTable.createdAt));

  const subtypeCounts: Record<string, number> = {};
  let hazardousCount = 0;
  let recyclableCount = 0;

  for (const scan of allEwaste) {
    subtypeCounts[scan.subType] = (subtypeCounts[scan.subType] ?? 0) + 1;
    if (!scan.recyclable) hazardousCount++;
    else recyclableCount++;
  }

  const topSubtypes = Object.entries(subtypeCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([subType, count]) => ({ subType, count }));

  const zoneBreakdown: Record<string, number> = {};
  for (const scan of allEwaste) {
    if (scan.zone) {
      zoneBreakdown[scan.zone] = (zoneBreakdown[scan.zone] ?? 0) + 1;
    }
  }

  res.json({
    totalEwaste: totals.total,
    hazardousCount,
    recyclableCount,
    topSubtypes,
    zoneBreakdown,
  });
});

router.get("/ewaste/scans", async (req, res): Promise<void> => {
  const limit = Math.min(Number(req.query.limit ?? 50), 100);
  const offset = Number(req.query.offset ?? 0);
  const subType = req.query.subType as string | undefined;

  let conditions = [eq(scansTable.category, "E-Waste")];
  if (subType) {
    conditions.push(eq(scansTable.subType, subType));
  }

  const scans = await db
    .select({
      id: scansTable.id,
      userId: scansTable.userId,
      subType: scansTable.subType,
      disposalInstructions: scansTable.disposalInstructions,
      recyclable: scansTable.recyclable,
      creditsEarned: scansTable.creditsEarned,
      confidence: scansTable.confidence,
      zone: scansTable.zone,
      feedbackCorrect: scansTable.feedbackCorrect,
      createdAt: scansTable.createdAt,
      userName: usersTable.name,
    })
    .from(scansTable)
    .leftJoin(usersTable, eq(scansTable.userId, usersTable.id))
    .where(and(...conditions))
    .orderBy(desc(scansTable.createdAt))
    .limit(limit)
    .offset(offset);

  res.json(scans);
});

export default router;
