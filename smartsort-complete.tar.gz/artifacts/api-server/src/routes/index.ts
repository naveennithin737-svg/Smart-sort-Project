import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import classifyRouter from "./classify";
import usersRouter from "./users";
import rewardsRouter from "./rewards";
import referralsRouter from "./referrals";
import leaderboardRouter from "./leaderboard";
import communityRouter from "./community";
import adminRouter from "./admin";
import ewasteRouter from "./ewaste";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(classifyRouter);
router.use(usersRouter);
router.use(rewardsRouter);
router.use(referralsRouter);
router.use(leaderboardRouter);
router.use(communityRouter);
router.use(adminRouter);
router.use(ewasteRouter);

export default router;
