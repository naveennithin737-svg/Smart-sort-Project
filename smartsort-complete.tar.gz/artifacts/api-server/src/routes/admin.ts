import { Router } from "express";
import { db } from "@workspace/db";
import { scansTable, usersTable, transactionsTable } from "@workspace/db";
import { eq, count, sum, gte, sql, and } from "drizzle-orm";
import { AdminLoginBody } from "@workspace/api-zod";
import { signToken } from "../middlewares/auth";

const router = Router();

const ADMIN_USERNAME = "admin";
const ADMIN_PASSWORD = "smartsort2024";

const MANGALURU_ZONES = [
  { name: "Kadri", lat: 12.8774, lng: 74.8535 },
  { name: "Bejai", lat: 12.8680, lng: 74.8420 },
  { name: "Mangaladevi", lat: 12.8580, lng: 74.8430 },
  { name: "Balmatta", lat: 12.8730, lng: 74.8490 },
  { name: "Pandeshwar", lat: 12.8700, lng: 74.8390 },
  { name: "Kankanady", lat: 12.8620, lng: 74.8340 },
  { name: "Attavar", lat: 12.8810, lng: 74.8470 },
];

router.post("/admin/login", async (req, res): Promise<void> => {
  const body = AdminLoginBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  if (body.data.username !== ADMIN_USERNAME || body.data.password !== ADMIN_PASSWORD) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }
  const token = signToken(-1, true);
  res.json({ token, username: ADMIN_USERNAME });
});

router.get("/admin/analytics", async (req, res): Promise<void> => {
  const [totalUsers] = await db.select({ total: count() }).from(usersTable).where(eq(usersTable.isAdmin, false));
  const oneMonthAgo = new Date();
  oneMonthAgo.setDate(oneMonthAgo.getDate() - 30);
  const [monthlyScans] = await db.select({ total: count() }).from(scansTable).where(gte(scansTable.createdAt, oneMonthAgo));
  const [allScans] = await db.select({ total: count() }).from(scansTable);
  const [recycledScans] = await db.select({ total: count() }).from(scansTable).where(eq(scansTable.recyclable, true));
  const [correctFeedback] = await db.select({ total: count() }).from(scansTable).where(eq(scansTable.feedbackCorrect, true));
  const [totalFeedback] = await db.select({ total: count() }).from(scansTable).where(sql`${scansTable.feedbackCorrect} IS NOT NULL`);
  const [creditsSum] = await db.select({ total: sum(usersTable.ecoCredits) }).from(usersTable);

  const totalScansCount = Number(allScans.total ?? 0);
  const recycledCount = Number(recycledScans.total ?? 0);
  const recyclablePercent = totalScansCount > 0 ? Math.round((recycledCount / totalScansCount) * 100) : 0;
  const feedbackCount = Number(totalFeedback.total ?? 0);
  const correctCount = Number(correctFeedback.total ?? 0);
  const feedbackAccuracyPercent = feedbackCount > 0 ? Math.round((correctCount / feedbackCount) * 100) : 95;

  const [topCat] = await db.select({
    category: scansTable.category,
    cnt: count(),
  }).from(scansTable).groupBy(scansTable.category).orderBy(sql`count(*) desc`).limit(1);

  const usersCount = Number(totalUsers.total ?? 0);
  const totalCredits = Number(creditsSum.total ?? 0);

  res.json({
    totalUsersRegistered: usersCount,
    totalScansThisMonth: Number(monthlyScans.total ?? 0),
    totalCo2SavedKg: Math.round(recycledCount * 0.3 * 10) / 10,
    recyclablePercent,
    activeZones: MANGALURU_ZONES.length,
    averageCreditsPerUser: usersCount > 0 ? Math.round(totalCredits / usersCount) : 0,
    topWasteType: topCat?.category ?? "Plastic",
    feedbackAccuracyPercent,
  });
});

router.get("/admin/zones", async (req, res): Promise<void> => {
  const zoneScanCounts = await Promise.all(
    MANGALURU_ZONES.map(async (zone) => {
      const [total] = await db.select({ cnt: count() }).from(scansTable).where(eq(scansTable.zone, zone.name));
      const [recycled] = await db.select({ cnt: count() }).from(scansTable).where(and(eq(scansTable.zone, zone.name), eq(scansTable.recyclable, true)));
      const [topCat] = await db.select({ category: scansTable.category, cnt: count() })
        .from(scansTable).where(eq(scansTable.zone, zone.name))
        .groupBy(scansTable.category).orderBy(sql`count(*) desc`).limit(1);

      const totalCount = Number(total.cnt ?? 0);
      let hotspotLevel = "low";
      if (totalCount >= 50) hotspotLevel = "critical";
      else if (totalCount >= 20) hotspotLevel = "high";
      else if (totalCount >= 5) hotspotLevel = "medium";

      return {
        name: zone.name,
        totalScans: totalCount,
        recyclableCount: Number(recycled.cnt ?? 0),
        hotspotLevel,
        latitude: zone.lat,
        longitude: zone.lng,
        dominantWasteType: topCat?.category ?? "Plastic",
      };
    })
  );
  res.json(zoneScanCounts);
});

router.get("/admin/collection-efficiency", async (req, res): Promise<void> => {
  const days = Math.min(Number(req.query.days) || 7, 30);
  const results = [];

  for (let i = days - 1; i >= 0; i--) {
    const dayStart = new Date();
    dayStart.setDate(dayStart.getDate() - i);
    dayStart.setHours(0, 0, 0, 0);
    const dayEnd = new Date(dayStart);
    dayEnd.setHours(23, 59, 59, 999);

    const [totalDay] = await db.select({ cnt: count() }).from(scansTable)
      .where(and(gte(scansTable.createdAt, dayStart), sql`${scansTable.createdAt} <= ${dayEnd}`));
    const [recycledDay] = await db.select({ cnt: count() }).from(scansTable)
      .where(and(eq(scansTable.recyclable, true), gte(scansTable.createdAt, dayStart), sql`${scansTable.createdAt} <= ${dayEnd}`));

    const totalCount = Number(totalDay.cnt ?? 0);
    const recycledCount = Number(recycledDay.cnt ?? 0);
    const efficiencyPercent = totalCount > 0 ? Math.round((recycledCount / totalCount) * 100) : 0;

    results.push({
      date: dayStart.toISOString().split("T")[0],
      scansCount: totalCount,
      recyclableCount: recycledCount,
      efficiencyPercent,
      co2SavedKg: Math.round(recycledCount * 0.3 * 10) / 10,
    });
  }
  res.json(results);
});

export default router;
