import { Router } from "express";
import { db } from "@workspace/db";
import { rewardsTable, transactionsTable, usersTable, vouchersTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { RedeemRewardParams, RedeemRewardBody } from "@workspace/api-zod";
import { nanoid } from "../lib/nanoid";

const router = Router();

router.get("/rewards", async (req, res): Promise<void> => {
  const rewards = await db.select().from(rewardsTable).orderBy(desc(rewardsTable.createdAt));
  res.json(rewards);
});

router.post("/rewards/:id/redeem", async (req, res): Promise<void> => {
  const params = RedeemRewardParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid reward ID" });
    return;
  }
  const body = RedeemRewardBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [reward] = await db.select().from(rewardsTable).where(eq(rewardsTable.id, params.data.id));
  if (!reward || !reward.available) {
    res.status(400).json({ error: "Reward not available" });
    return;
  }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, body.data.userId));
  if (!user) {
    res.status(400).json({ error: "User not found" });
    return;
  }
  if (user.ecoCredits < reward.creditCost) {
    res.status(400).json({ error: "Insufficient Eco-Credits" });
    return;
  }

  const newCredits = user.ecoCredits - reward.creditCost;
  await db.update(usersTable).set({ ecoCredits: newCredits }).where(eq(usersTable.id, body.data.userId));

  const voucherCode = `SS-${nanoid(6).toUpperCase()}`;
  await db.insert(vouchersTable).values({
    userId: body.data.userId,
    rewardId: reward.id,
    code: voucherCode,
  });

  await db.insert(transactionsTable).values({
    userId: body.data.userId,
    amount: -reward.creditCost,
    type: "redeem",
    description: `Redeemed: ${reward.title} from ${reward.partner}`,
  });

  res.json({
    success: true,
    voucherCode,
    remainingCredits: newCredits,
    reward: {
      id: reward.id,
      title: reward.title,
      description: reward.description,
      partner: reward.partner,
      creditCost: reward.creditCost,
      category: reward.category,
      available: reward.available,
      imageUrl: reward.imageUrl,
      expiresAt: reward.expiresAt,
    },
  });
});

export default router;
