import { Router } from "express";
import bcrypt from "bcryptjs";
import { db } from "@workspace/db";
import { usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { RegisterBody, LoginBody } from "@workspace/api-zod";
import { authMiddleware, signToken, type AuthRequest } from "../middlewares/auth";
import { nanoid } from "../lib/nanoid";

const router = Router();

router.post("/auth/register", async (req, res): Promise<void> => {
  const parsed = RegisterBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { name, email, password } = parsed.data;

  const existing = await db.select().from(usersTable).where(eq(usersTable.email, email));
  if (existing.length > 0) {
    res.status(400).json({ error: "Email already registered" });
    return;
  }

  const passwordHash = await bcrypt.hash(password, 10);
  const referralCode = nanoid(8).toUpperCase();

  const [user] = await db.insert(usersTable).values({
    name,
    email,
    passwordHash,
    referralCode,
    ecoCredits: 0,
    totalScans: 0,
    isAdmin: false,
    tutorialSeen: false,
  }).returning();

  const token = signToken(user.id, user.isAdmin);
  res.status(201).json({
    token,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      ecoCredits: user.ecoCredits,
      totalScans: user.totalScans,
      referralCode: user.referralCode,
      isAdmin: user.isAdmin,
      createdAt: user.createdAt,
    },
  });
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { email, password } = parsed.data;

  const [user] = await db.select().from(usersTable).where(eq(usersTable.email, email));
  if (!user) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }

  const token = signToken(user.id, user.isAdmin);
  res.json({
    token,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      ecoCredits: user.ecoCredits,
      totalScans: user.totalScans,
      referralCode: user.referralCode,
      isAdmin: user.isAdmin,
      createdAt: user.createdAt,
    },
  });
});

router.get("/auth/me", authMiddleware, async (req: AuthRequest, res): Promise<void> => {
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.userId!));
  if (!user) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  res.json({
    id: user.id,
    name: user.name,
    email: user.email,
    ecoCredits: user.ecoCredits,
    totalScans: user.totalScans,
    referralCode: user.referralCode,
    isAdmin: user.isAdmin,
    createdAt: user.createdAt,
  });
});

export default router;
