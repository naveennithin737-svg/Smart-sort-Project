import { Router } from "express";
import { db } from "@workspace/db";
import { usersTable, referralsTable, transactionsTable } from "@workspace/db";
import { eq, sum } from "drizzle-orm";
import { ApplyReferralCodeBody, GetMyReferralCodeQueryParams } from "@workspace/api-zod";

const router = Router();

router.get("/referrals/my-code", async (req, res): Promise<void> => {
  const params = GetMyReferralCodeQueryParams.safeParse(req.query);
  if (!params.success) {
    res.status(400).json({ error: "userId is required" });
    return;
  }
  const userId = params.data.userId;
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  const refs = await db.select().from(referralsTable).where(eq(referralsTable.referrerId, userId));
  const creditsFromReferrals = refs.filter((r) => r.bonusAwarded).length * 50;

  const baseUrl = process.env.REPLIT_DOMAINS
    ? `https://${process.env.REPLIT_DOMAINS.split(",")[0]}`
    : "http://localhost:80";

  res.json({
    code: user.referralCode,
    totalReferrals: refs.length,
    creditsEarned: creditsFromReferrals,
    referralUrl: `${baseUrl}/?ref=${user.referralCode}`,
  });
});

router.post("/referrals/apply", async (req, res): Promise<void> => {
  const body = ApplyReferralCodeBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const { code, newUserId } = body.data;

  const [referrer] = await db.select().from(usersTable).where(eq(usersTable.referralCode, code));
  if (!referrer) {
    res.status(400).json({ error: "Invalid referral code" });
    return;
  }
  if (referrer.id === newUserId) {
    res.status(400).json({ error: "Cannot use your own referral code" });
    return;
  }

  const existing = await db.select().from(referralsTable).where(eq(referralsTable.referredUserId, newUserId));
  if (existing.length > 0) {
    res.status(400).json({ error: "Referral code already applied" });
    return;
  }

  await db.insert(referralsTable).values({
    referrerId: referrer.id,
    referredUserId: newUserId,
    bonusAwarded: false,
  });

  res.json({
    success: true,
    bonusCredits: 50,
    referrerName: referrer.name,
  });
});

export default router;
