import { Router } from "express";
import { db } from "@workspace/db";
import { scansTable, transactionsTable, usersTable, referralsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { ClassifyWasteBody, SubmitFeedbackBody, SubmitFeedbackParams, ListScansQueryParams } from "@workspace/api-zod";
import { ai } from "@workspace/integrations-gemini-ai";

const router = Router();

const ZONES = ["Kadri", "Bejai", "Mangaladevi", "Balmatta", "Pandeshwar", "Kankanady", "Attavar"];

function getRandomZone(): string {
  return ZONES[Math.floor(Math.random() * ZONES.length)];
}

function computeCredits(recyclable: boolean, confidence: number): number {
  const base = recyclable ? 15 : 10;
  const bonus = confidence > 0.9 ? 5 : confidence > 0.75 ? 2 : 0;
  return base + bonus;
}

export function getBadge(credits: number): string {
  if (credits >= 2000) return "Planet Champion";
  if (credits >= 1000) return "Eco-Hero";
  if (credits >= 500) return "Waste Warrior";
  if (credits >= 200) return "Green Guardian";
  return "Eco-Novice";
}

router.post("/classify", async (req, res): Promise<void> => {
  const parsed = ClassifyWasteBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { imageBase64, mimeType, userId } = parsed.data;

  const prompt = `You are a waste classification AI for SmartSort, deployed in Mangaluru, India. Analyze this waste item image carefully and respond ONLY with valid JSON in this exact format — no extra text, no markdown, just the JSON object:
{
  "category": "<one of: Plastic, Glass, Metal, Paper, Organic, E-Waste, Hazardous, Mixed>",
  "subType": "<specific sub-type. For E-Waste use: Smartphone, Laptop, Tablet, CRT Monitor, LCD Monitor, Keyboard, Mouse, Printer, Battery (Li-ion), Battery (Lead-acid), Battery (NiCd), Charger/Adapter, Headphones, TV, Refrigerator, Washing Machine, Microwave, PCB/Circuit Board, Hard Drive, Camera, UPS, Unknown E-Waste. For Plastic use: PET, HDPE, LDPE, PP, PVC, PS, PC. For Metal: Aluminum Can, Steel, Copper Wire. For others use appropriate sub-type.>",
  "brand": "<detected brand/manufacturer if visible, else null>",
  "model": "<detected model if visible, else null>",
  "hazardousComponents": "<for E-Waste only: list materials like Lead, Mercury, Cadmium, Chromium, BFRs, CFCs — comma separated; for others null>",
  "disposalInstructions": "<clear 2-3 sentence instructions for proper disposal in Mangaluru, India — mention specific drop-off locations for E-Waste like MPCB E-Waste collection center at Kadri, or Attavar KSPCB facility>",
  "recyclable": <true or false>,
  "confidence": <number between 0 and 1>,
  "tips": ["<actionable tip 1>", "<actionable tip 2>", "<actionable tip 3>"]
}

For E-Waste items, be very specific about hazardous components, and always mention Mangaluru's MPCB E-Waste collection centre or KSPCB authorized e-waste recyclers in disposal instructions.`;

  let classification: {
    category: string;
    subType: string;
    brand: string | null;
    model: string | null;
    hazardousComponents: string | null;
    disposalInstructions: string;
    recyclable: boolean;
    confidence: number;
    tips: string[];
  };

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [
        {
          role: "user",
          parts: [
            {
              inlineData: {
                mimeType,
                data: imageBase64,
              },
            },
            { text: prompt },
          ],
        },
      ],
      config: {
        responseMimeType: "application/json",
        maxOutputTokens: 8192,
      },
    });

    const text = response.text ?? "{}";
    const jsonStr = text.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
    classification = JSON.parse(jsonStr);
  } catch {
    classification = {
      category: "Mixed",
      subType: "Unknown",
      brand: null,
      model: null,
      hazardousComponents: null,
      disposalInstructions: "Unable to classify. Please take to your nearest waste collection center in Mangaluru.",
      recyclable: false,
      confidence: 0.5,
      tips: [
        "When in doubt, take to the nearest waste collection center",
        "Separate wet and dry waste",
        "Avoid mixing hazardous items with regular waste",
      ],
    };
  }

  const creditsEarned = computeCredits(classification.recyclable, classification.confidence);
  const zone = getRandomZone();

  const [scan] = await db.insert(scansTable).values({
    userId: userId ?? 0,
    category: classification.category,
    subType: classification.subType,
    disposalInstructions: classification.disposalInstructions,
    recyclable: classification.recyclable,
    creditsEarned,
    confidence: classification.confidence,
    zone,
  }).returning();

  if (userId) {
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
    if (user) {
      const newCredits = user.ecoCredits + creditsEarned;
      const newScans = user.totalScans + 1;
      await db.update(usersTable).set({
        ecoCredits: newCredits,
        totalScans: newScans,
      }).where(eq(usersTable.id, userId));

      await db.insert(transactionsTable).values({
        userId,
        amount: creditsEarned,
        type: "scan",
        description: `Classified ${classification.subType} — earned ${creditsEarned} Eco-Credits`,
      });

      if (newScans === 1) {
        const refs = await db.select().from(referralsTable).where(eq(referralsTable.referredUserId, userId));
        if (refs.length > 0) {
          const ref = refs[0];
          if (!ref.bonusAwarded) {
            await db.update(referralsTable).set({ bonusAwarded: true }).where(eq(referralsTable.id, ref.id));

            await db.update(usersTable).set({ ecoCredits: newCredits + 50 }).where(eq(usersTable.id, userId));
            await db.insert(transactionsTable).values({
              userId,
              amount: 50,
              type: "referral_bonus",
              description: "Referral bonus for completing your first scan!",
            });

            const [referrer] = await db.select().from(usersTable).where(eq(usersTable.id, ref.referrerId));
            if (referrer) {
              await db.update(usersTable).set({ ecoCredits: referrer.ecoCredits + 50 }).where(eq(usersTable.id, ref.referrerId));
              await db.insert(transactionsTable).values({
                userId: ref.referrerId,
                amount: 50,
                type: "referral_bonus",
                description: "Referral bonus — your friend completed their first scan!",
              });
            }
          }
        }
      }
    }
  }

  res.json({
    scanId: scan.id,
    category: classification.category,
    subType: classification.subType,
    brand: classification.brand ?? null,
    model: classification.model ?? null,
    hazardousComponents: classification.hazardousComponents ?? null,
    disposalInstructions: classification.disposalInstructions,
    recyclable: classification.recyclable,
    creditsEarned,
    confidence: classification.confidence,
    tips: classification.tips,
    zone,
  });
});

router.get("/scans", async (req, res): Promise<void> => {
  const params = ListScansQueryParams.safeParse(req.query);
  const limit = params.success ? (params.data.limit ?? 20) : 20;
  const offset = params.success ? (params.data.offset ?? 0) : 0;
  const userId = params.success ? params.data.userId : undefined;

  let baseQuery = db.select().from(scansTable).$dynamic();
  if (userId) {
    baseQuery = baseQuery.where(eq(scansTable.userId, userId));
  }
  const scans = await baseQuery.orderBy(desc(scansTable.createdAt)).limit(limit).offset(offset);
  res.json(scans);
});

router.post("/scans/:id/feedback", async (req, res): Promise<void> => {
  const params = SubmitFeedbackParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid scan ID" });
    return;
  }
  const body = SubmitFeedbackBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [scan] = await db.select().from(scansTable).where(eq(scansTable.id, params.data.id));
  if (!scan) {
    res.status(404).json({ error: "Scan not found" });
    return;
  }

  const [updated] = await db.update(scansTable).set({
    feedbackCorrect: body.data.correct,
    feedbackNote: body.data.note,
    correctCategory: body.data.correctCategory,
  }).where(eq(scansTable.id, params.data.id)).returning();

  res.json(updated);
});

export default router;
