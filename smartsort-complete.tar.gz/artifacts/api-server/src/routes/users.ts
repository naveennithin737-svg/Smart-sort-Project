import { Router } from "express";
import { db } from "@workspace/db";
import { usersTable, transactionsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { GetUserParams, ListTransactionsParams } from "@workspace/api-zod";

const router = Router();

const LEVEL_THRESHOLDS = [0, 100, 300, 600, 1200, 2500];
const BADGES = ["Eco-Novice", "Green Guardian", "Waste Warrior", "Eco-Hero", "Planet Champion", "Planet Champion"];

router.get("/users/:id", async (req, res): Promise<void> => {
  const params = GetUserParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid user ID" });
    return;
  }
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, params.data.id));
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  res.json({
    id: user.id,
    name: user.name,
    email: user.email,
    ecoCredits: user.ecoCredits,
    totalScans: user.totalScans,
    referralCode: user.referralCode,
    isAdmin: user.isAdmin,
    createdAt: user.createdAt,
  });
});

router.get("/users/:id/transactions", async (req, res): Promise<void> => {
  const params = ListTransactionsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid user ID" });
    return;
  }
  const limit = Number(req.query.limit) || 20;
  const txns = await db.select().from(transactionsTable)
    .where(eq(transactionsTable.userId, params.data.id))
    .orderBy(desc(transactionsTable.createdAt))
    .limit(limit);
  res.json(txns);
});

router.get("/users/:id/level", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid user ID" });
    return;
  }
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, id));
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  const credits = user.ecoCredits;
  let level = 0;
  for (let i = 0; i < LEVEL_THRESHOLDS.length - 1; i++) {
    if (credits >= LEVEL_THRESHOLDS[i]) level = i;
    else break;
  }
  const currentThreshold = LEVEL_THRESHOLDS[level] ?? 0;
  const nextThreshold = LEVEL_THRESHOLDS[level + 1] ?? credits + 1;
  const progressPercent = Math.min(
    ((credits - currentThreshold) / (nextThreshold - currentThreshold)) * 100,
    100
  );

  const allUsers = await db.select({ id: usersTable.id, ecoCredits: usersTable.ecoCredits })
    .from(usersTable)
    .orderBy(desc(usersTable.ecoCredits));
  const rank = allUsers.findIndex((u) => u.id === id) + 1;

  res.json({
    level: level + 1,
    badge: BADGES[level] ?? "Eco-Novice",
    currentCredits: credits,
    creditsForNextLevel: nextThreshold,
    progressPercent: Math.round(progressPercent),
    totalScans: user.totalScans,
    rank,
  });
});

export default router;
