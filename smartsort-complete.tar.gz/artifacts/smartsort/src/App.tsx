import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Scan from "@/pages/scan";
import Dashboard from "@/pages/dashboard";
import Rewards from "@/pages/rewards";
import Refer from "@/pages/refer";
import Leaderboard from "@/pages/leaderboard";
import Login from "@/pages/auth/login";
import Register from "@/pages/auth/register";
import AdminPortal from "@/pages/admin";
import EWasteData from "@/pages/ewaste";

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/scan" component={Scan} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/rewards" component={Rewards} />
      <Route path="/refer" component={Refer} />
      <Route path="/leaderboard" component={Leaderboard} />
      <Route path="/auth/login" component={Login} />
      <Route path="/auth/register" component={Register} />
      <Route path="/admin" component={AdminPortal} />
      <Route path="/ewaste" component={EWasteData} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
