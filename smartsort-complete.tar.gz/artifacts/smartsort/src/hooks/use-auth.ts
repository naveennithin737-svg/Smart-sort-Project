import { create } from "zustand";
import { setAuthTokenGetter } from "@workspace/api-client-react";

function decodeJwtPayload(token: string): { userId: number; isAdmin: boolean } | null {
  try {
    const payload = token.split(".")[1];
    const decoded = JSON.parse(atob(payload));
    return { userId: decoded.userId, isAdmin: decoded.isAdmin ?? false };
  } catch {
    return null;
  }
}

interface AuthState {
  token: string | null;
  userId: number | null;
  isAdmin: boolean;
  setToken: (token: string | null) => void;
  logout: () => void;
}

const stored = localStorage.getItem("smartsort_token");
const storedPayload = stored ? decodeJwtPayload(stored) : null;

export const useAuth = create<AuthState>((set) => ({
  token: stored,
  userId: storedPayload?.userId ?? null,
  isAdmin: storedPayload?.isAdmin ?? false,
  setToken: (token) => {
    const payload = token ? decodeJwtPayload(token) : null;
    if (token) {
      localStorage.setItem("smartsort_token", token);
    } else {
      localStorage.removeItem("smartsort_token");
    }
    set({ token, userId: payload?.userId ?? null, isAdmin: payload?.isAdmin ?? false });
  },
  logout: () => {
    localStorage.removeItem("smartsort_token");
    set({ token: null, userId: null, isAdmin: false });
  },
}));

setAuthTokenGetter(() => localStorage.getItem("smartsort_token"));
