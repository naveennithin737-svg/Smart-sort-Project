import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";
import { 
  ScanLine, 
  Home, 
  LayoutDashboard, 
  Gift, 
  Users, 
  Trophy,
  LogOut,
  Menu,
  X,
  Cpu
} from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { token, logout } = useAuth();
  const queryClient = useQueryClient();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const { data: user } = useGetMe({ 
    query: { 
      enabled: !!token, 
      queryKey: getGetMeQueryKey() 
    } 
  });

  const handleLogout = () => {
    logout();
    queryClient.clear();
  };

  const closeMenu = () => setIsMobileMenuOpen(false);

  const navItems = [
    { href: "/", label: "Home", icon: Home, show: true },
    { href: "/scan", label: "Scan Waste", icon: ScanLine, show: true },
    { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard, show: !!token },
    { href: "/rewards", label: "Rewards", icon: Gift, show: !!token },
    { href: "/refer", label: "Refer", icon: Users, show: !!token },
    { href: "/leaderboard", label: "Leaderboard", icon: Trophy, show: true },
    { href: "/ewaste", label: "E-Waste Data", icon: Cpu, show: true },
    { href: "/admin", label: "Admin", icon: LayoutDashboard, show: !!user?.isAdmin },
  ];

  return (
    <div className="min-h-[100dvh] flex flex-col bg-background">
      <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2 font-bold text-xl tracking-tight text-primary">
              <ScanLine className="h-6 w-6" />
              <span>SmartSort</span>
            </Link>
          </div>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-6">
            {navItems.filter(item => item.show).map((item) => (
              <Link 
                key={item.href} 
                href={item.href}
                className={`text-sm font-medium transition-colors hover:text-primary ${
                  location === item.href ? "text-primary" : "text-muted-foreground"
                }`}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-4">
            {token ? (
              <div className="flex items-center gap-4">
                <span className="text-sm font-medium text-muted-foreground">
                  {user?.ecoCredits ?? 0} Credits
                </span>
                <Button variant="ghost" size="sm" onClick={handleLogout} className="gap-2">
                  <LogOut className="h-4 w-4" />
                  Logout
                </Button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Link href="/auth/login">
                  <Button variant="ghost" size="sm">Login</Button>
                </Link>
                <Link href="/auth/register">
                  <Button size="sm">Register</Button>
                </Link>
              </div>
            )}
          </div>

          {/* Mobile Menu Toggle */}
          <button 
            className="md:hidden p-2 text-foreground"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </header>

      {/* Mobile Nav */}
      {isMobileMenuOpen && (
        <div className="md:hidden fixed inset-0 top-16 z-40 bg-background border-t border-border">
          <nav className="flex flex-col p-4 gap-2">
            {navItems.filter(item => item.show).map((item) => (
              <Link 
                key={item.href} 
                href={item.href}
                onClick={closeMenu}
                className={`flex items-center gap-3 px-4 py-3 rounded-md text-base font-medium transition-colors ${
                  location === item.href ? "bg-primary/10 text-primary" : "text-foreground hover:bg-muted"
                }`}
              >
                <item.icon className="h-5 w-5" />
                {item.label}
              </Link>
            ))}
            <div className="h-px bg-border my-2" />
            {token ? (
              <>
                <div className="px-4 py-3 text-sm font-medium text-muted-foreground">
                  Balance: <span className="text-primary">{user?.ecoCredits ?? 0} Credits</span>
                </div>
                <button 
                  onClick={() => { handleLogout(); closeMenu(); }}
                  className="flex items-center gap-3 px-4 py-3 rounded-md text-base font-medium text-destructive hover:bg-destructive/10 text-left"
                >
                  <LogOut className="h-5 w-5" />
                  Logout
                </button>
              </>
            ) : (
              <div className="flex flex-col gap-2 p-2">
                <Link href="/auth/login" onClick={closeMenu}>
                  <Button variant="outline" className="w-full">Login</Button>
                </Link>
                <Link href="/auth/register" onClick={closeMenu}>
                  <Button className="w-full">Register</Button>
                </Link>
              </div>
            )}
          </nav>
        </div>
      )}

      <main className="flex-1">
        {children}
      </main>
    </div>
  );
}
