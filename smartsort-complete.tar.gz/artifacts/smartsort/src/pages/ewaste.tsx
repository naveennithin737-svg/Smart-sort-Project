import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Layout } from "@/components/layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import {
  Cpu, Biohazard, Recycle, MapPin, ScanLine,
  TrendingUp, Package, AlertTriangle, CheckCircle, Filter
} from "lucide-react";
import { format } from "date-fns";
import {
  PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip,
  ResponsiveContainer, Legend
} from "recharts";
import { motion } from "framer-motion";

const BASE_URL = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";

async function fetchEwasteStats() {
  const res = await fetch(`${BASE_URL}/api/ewaste/stats`);
  if (!res.ok) throw new Error("Failed to fetch e-waste stats");
  return res.json() as Promise<{
    totalEwaste: number;
    hazardousCount: number;
    recyclableCount: number;
    topSubtypes: { subType: string; count: number }[];
    zoneBreakdown: Record<string, number>;
  }>;
}

async function fetchEwasteScans(subType?: string) {
  const url = subType
    ? `${BASE_URL}/api/ewaste/scans?limit=50&subType=${encodeURIComponent(subType)}`
    : `${BASE_URL}/api/ewaste/scans?limit=50`;
  const res = await fetch(url);
  if (!res.ok) throw new Error("Failed to fetch e-waste scans");
  return res.json() as Promise<{
    id: number;
    userId: number | null;
    subType: string;
    disposalInstructions: string;
    recyclable: boolean;
    creditsEarned: number;
    confidence: number;
    zone: string | null;
    feedbackCorrect: boolean | null;
    createdAt: string;
    userName: string | null;
  }[]>;
}

const PIE_COLORS = ["#8b5cf6", "#a78bfa", "#c4b5fd", "#6d28d9", "#7c3aed", "#4c1d95"];
const ZONE_COLORS = ["#10b981", "#34d399", "#6ee7b7", "#059669", "#047857", "#065f46", "#064e3b"];

export default function EWasteData() {
  const [selectedSubtype, setSelectedSubtype] = useState<string | undefined>();

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["ewaste-stats"],
    queryFn: fetchEwasteStats,
    refetchInterval: 30000,
  });

  const { data: scans, isLoading: scansLoading } = useQuery({
    queryKey: ["ewaste-scans", selectedSubtype],
    queryFn: () => fetchEwasteScans(selectedSubtype),
    refetchInterval: 30000,
  });

  const zoneData = stats
    ? Object.entries(stats.zoneBreakdown).map(([zone, count]) => ({ zone, count }))
    : [];

  return (
    <Layout>
      <div className="container py-8 space-y-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 rounded-lg bg-violet-100 dark:bg-violet-900/30">
                <Cpu className="w-6 h-6 text-violet-600" />
              </div>
              <h1 className="text-3xl font-bold tracking-tight">E-Waste Data</h1>
            </div>
            <p className="text-muted-foreground">
              All electronic waste scanned and tracked across Mangaluru's zones.
            </p>
          </div>
          <Link href="/scan">
            <Button className="gap-2 shrink-0">
              <ScanLine className="w-4 h-4" /> Scan E-Waste
            </Button>
          </Link>
        </div>

        {/* Stats Cards */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0 }}>
            <Card className="bg-violet-50 dark:bg-violet-950/20 border-violet-200 dark:border-violet-800/40">
              <CardContent className="p-5">
                <div className="flex items-center justify-between mb-3">
                  <Cpu className="w-5 h-5 text-violet-500" />
                  <Badge variant="secondary" className="text-xs">Total</Badge>
                </div>
                <div className="text-3xl font-bold text-violet-700 dark:text-violet-300">
                  {statsLoading ? "—" : stats?.totalEwaste ?? 0}
                </div>
                <p className="text-xs text-muted-foreground mt-1">E-waste items scanned</p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
            <Card className="bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-800/40">
              <CardContent className="p-5">
                <div className="flex items-center justify-between mb-3">
                  <Biohazard className="w-5 h-5 text-red-500" />
                  <Badge variant="secondary" className="text-xs bg-red-100 text-red-700">Hazardous</Badge>
                </div>
                <div className="text-3xl font-bold text-red-700 dark:text-red-300">
                  {statsLoading ? "—" : stats?.hazardousCount ?? 0}
                </div>
                <p className="text-xs text-muted-foreground mt-1">Non-recyclable / hazardous</p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
            <Card className="bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-800/40">
              <CardContent className="p-5">
                <div className="flex items-center justify-between mb-3">
                  <Recycle className="w-5 h-5 text-green-500" />
                  <Badge variant="secondary" className="text-xs bg-green-100 text-green-700">Recyclable</Badge>
                </div>
                <div className="text-3xl font-bold text-green-700 dark:text-green-300">
                  {statsLoading ? "—" : stats?.recyclableCount ?? 0}
                </div>
                <p className="text-xs text-muted-foreground mt-1">Recoverable e-waste</p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
            <Card className="bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800/40">
              <CardContent className="p-5">
                <div className="flex items-center justify-between mb-3">
                  <Package className="w-5 h-5 text-blue-500" />
                  <Badge variant="secondary" className="text-xs bg-blue-100 text-blue-700">Types</Badge>
                </div>
                <div className="text-3xl font-bold text-blue-700 dark:text-blue-300">
                  {statsLoading ? "—" : stats?.topSubtypes.length ?? 0}
                </div>
                <p className="text-xs text-muted-foreground mt-1">Distinct e-waste sub-types</p>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Charts Row */}
        {stats && (stats.topSubtypes.length > 0 || zoneData.length > 0) && (
          <div className="grid gap-6 md:grid-cols-2">
            {/* Subtype Pie */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-violet-500" />
                  E-Waste by Sub-type
                </CardTitle>
                <CardDescription>Top categories collected across Mangaluru</CardDescription>
              </CardHeader>
              <CardContent>
                {stats.topSubtypes.length === 0 ? (
                  <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">
                    No data yet. Start scanning e-waste items!
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height={220}>
                    <PieChart>
                      <Pie
                        data={stats.topSubtypes}
                        dataKey="count"
                        nameKey="subType"
                        cx="50%"
                        cy="50%"
                        outerRadius={80}
                        label={({ subType, percent }) =>
                          `${subType} ${(percent * 100).toFixed(0)}%`
                        }
                        labelLine={false}
                      >
                        {stats.topSubtypes.map((_, i) => (
                          <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(v) => [`${v} items`, "Count"]} />
                    </PieChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>

            {/* Zone Bar Chart */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-green-500" />
                  E-Waste by Zone
                </CardTitle>
                <CardDescription>Distribution across Mangaluru municipal zones</CardDescription>
              </CardHeader>
              <CardContent>
                {zoneData.length === 0 ? (
                  <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">
                    No zone data yet.
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height={220}>
                    <BarChart data={zoneData} margin={{ top: 0, right: 0, bottom: 0, left: -20 }}>
                      <XAxis dataKey="zone" tick={{ fontSize: 11 }} />
                      <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                      <Tooltip formatter={(v) => [`${v} items`, "Count"]} />
                      <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                        {zoneData.map((_, i) => (
                          <Cell key={i} fill={ZONE_COLORS[i % ZONE_COLORS.length]} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {/* Filter & Scan List */}
        <Card>
          <CardHeader className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Filter className="w-4 h-4" /> All E-Waste Records
              </CardTitle>
              <CardDescription>
                {scans ? `${scans.length} records` : "Loading..."}
                {selectedSubtype && ` • filtered by "${selectedSubtype}"`}
              </CardDescription>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button
                size="sm"
                variant={!selectedSubtype ? "default" : "outline"}
                onClick={() => setSelectedSubtype(undefined)}
                className="text-xs"
              >
                All
              </Button>
              {stats?.topSubtypes.slice(0, 5).map(({ subType }) => (
                <Button
                  key={subType}
                  size="sm"
                  variant={selectedSubtype === subType ? "default" : "outline"}
                  onClick={() => setSelectedSubtype(selectedSubtype === subType ? undefined : subType)}
                  className="text-xs"
                >
                  {subType}
                </Button>
              ))}
            </div>
          </CardHeader>
          <CardContent>
            {scansLoading ? (
              <div className="flex items-center justify-center py-12 text-muted-foreground gap-3">
                <div className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                Loading records...
              </div>
            ) : !scans || scans.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 text-muted-foreground gap-4">
                <Cpu className="w-12 h-12 opacity-20" />
                <div className="text-center">
                  <p className="font-medium">No e-waste records yet</p>
                  <p className="text-sm">Scan an electronic device to add it here.</p>
                </div>
                <Link href="/scan">
                  <Button size="sm" className="gap-2">
                    <ScanLine className="w-4 h-4" /> Scan Now
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="space-y-3">
                {scans.map((scan, i) => (
                  <motion.div
                    key={scan.id}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.03 }}
                    className="flex items-start justify-between p-4 rounded-xl border bg-card hover:bg-muted/40 transition-colors"
                  >
                    <div className="flex items-start gap-3 flex-1 min-w-0">
                      <div className="p-2 rounded-lg bg-violet-100 dark:bg-violet-900/30 shrink-0 mt-0.5">
                        <Cpu className="w-4 h-4 text-violet-600" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          <span className="font-semibold truncate">{scan.subType}</span>
                          {scan.recyclable ? (
                            <Badge className="bg-green-100 text-green-700 border-green-200 text-xs gap-1">
                              <CheckCircle className="w-2.5 h-2.5" /> Recyclable
                            </Badge>
                          ) : (
                            <Badge className="bg-red-100 text-red-700 border-red-200 text-xs gap-1">
                              <AlertTriangle className="w-2.5 h-2.5" /> Hazardous
                            </Badge>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground line-clamp-2 mb-2">
                          {scan.disposalInstructions}
                        </p>
                        <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                          {scan.zone && (
                            <span className="flex items-center gap-1">
                              <MapPin className="w-3 h-3" /> {scan.zone}
                            </span>
                          )}
                          {scan.userName && (
                            <span className="flex items-center gap-1">
                              by {scan.userName}
                            </span>
                          )}
                          <span>{format(new Date(scan.createdAt), "MMM d, yyyy h:mm a")}</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right shrink-0 pl-3">
                      <div className="text-sm font-bold text-primary">+{scan.creditsEarned}</div>
                      <div className="text-xs text-muted-foreground">credits</div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {Math.round(scan.confidence * 100)}% conf.
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Info Box */}
        <Card className="bg-violet-50 dark:bg-violet-950/20 border-violet-200 dark:border-violet-800/40">
          <CardContent className="p-5">
            <div className="flex items-start gap-3">
              <Biohazard className="w-5 h-5 text-violet-600 shrink-0 mt-0.5" />
              <div className="text-sm">
                <p className="font-semibold text-violet-700 dark:text-violet-300 mb-1">
                  Mangaluru E-Waste Drop-off Locations
                </p>
                <ul className="text-muted-foreground space-y-1">
                  <li>• MPCB E-Waste Collection Centre — Kadri, Mangaluru</li>
                  <li>• KSPCB Authorized Facility — Attavar, Mangaluru</li>
                  <li>• MCC Hazardous Waste Node — Balmatta, Mangaluru</li>
                  <li>• E-Parisaraa Pvt. Ltd. (KSPCB certified) — Pandeshwar</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
