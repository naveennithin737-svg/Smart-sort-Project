import { useState } from "react";
import { Layout } from "@/components/layout";
import { useAuth } from "@/hooks/use-auth";
import { 
  useGetAdminAnalytics, getGetAdminAnalyticsQueryKey,
  useGetWasteZones, getGetWasteZonesQueryKey,
  useGetCollectionEfficiency, getGetCollectionEfficiencyQueryKey,
  useAdminLogin
} from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer,
  BarChart, Bar
} from "recharts";
import { Users, ScanLine, Globe, Recycle, Activity, Loader2, ShieldCheck } from "lucide-react";
import { format, subDays } from "date-fns";

export default function AdminPortal() {
  const { token, setToken } = useAuth();
  const { toast } = useToast();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);

  const adminLoginMutation = useAdminLogin();

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    adminLoginMutation.mutate({
      data: { username, password }
    }, {
      onSuccess: (data) => {
        setToken(data.token);
        setIsAdminLoggedIn(true);
        toast({ title: "Admin login successful" });
      },
      onError: (err) => {
        toast({ variant: "destructive", title: "Login failed", description: err.message || "Invalid admin credentials" });
      }
    });
  };

  const { data: analytics, isLoading: analyticsLoading } = useGetAdminAnalytics({
    query: { enabled: isAdminLoggedIn, queryKey: getGetAdminAnalyticsQueryKey() }
  });

  const { data: zones, isLoading: zonesLoading } = useGetWasteZones({
    query: { enabled: isAdminLoggedIn, queryKey: getGetWasteZonesQueryKey() }
  });

  const { data: efficiency, isLoading: efficiencyLoading } = useGetCollectionEfficiency(
    { days: 7 },
    { query: { enabled: isAdminLoggedIn, queryKey: getGetCollectionEfficiencyQueryKey({ days: 7 }) } }
  );

  if (!isAdminLoggedIn) {
    return (
      <Layout>
        <div className="container max-w-md py-16">
          <Card className="border-primary/20 shadow-xl">
            <CardHeader className="text-center">
              <div className="mx-auto w-12 h-12 bg-primary/10 text-primary rounded-full flex items-center justify-center mb-4">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <CardTitle>Municipal Admin Portal</CardTitle>
              <CardDescription>Authorized personnel only</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleAdminLogin} className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Username</label>
                  <Input value={username} onChange={(e) => setUsername(e.target.value)} required />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Password</label>
                  <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
                </div>
                <Button type="submit" className="w-full" disabled={adminLoginMutation.isPending}>
                  {adminLoginMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : "Sign In"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </Layout>
    );
  }

  const getHotspotColor = (level: string) => {
    switch (level) {
      case "critical": return "bg-red-500/10 text-red-600 border-red-200 dark:border-red-900";
      case "high": return "bg-orange-500/10 text-orange-600 border-orange-200 dark:border-orange-900";
      case "medium": return "bg-amber-500/10 text-amber-600 border-amber-200 dark:border-amber-900";
      default: return "bg-green-500/10 text-green-600 border-green-200 dark:border-green-900";
    }
  };

  const isLoading = analyticsLoading || zonesLoading || efficiencyLoading;

  if (isLoading) {
    return (
      <Layout>
        <div className="container py-8 flex justify-center items-center h-[50vh]">
          <Loader2 className="w-12 h-12 animate-spin text-primary" />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container py-8 space-y-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Municipal Analytics Portal</h1>
          <p className="text-muted-foreground mt-2">Mangaluru Waste Intelligence Dashboard</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Total Registered Users</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{analytics?.totalUsersRegistered.toLocaleString() ?? 0}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Scans This Month</CardTitle>
              <ScanLine className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary">{analytics?.totalScansThisMonth.toLocaleString() ?? 0}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Recyclable Efficiency</CardTitle>
              <Recycle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{analytics?.recyclablePercent ?? 0}%</div>
              <p className="text-xs text-muted-foreground mt-1">Of all waste scanned</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">CO₂ Diverted (kg)</CardTitle>
              <Globe className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">{analytics?.totalCo2SavedKg.toLocaleString() ?? 0}</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Daily Collection Efficiency (7-Day)</CardTitle>
              <CardDescription>Percentage of correctly sorted recyclable waste</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={efficiency || []} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="date" 
                    tickFormatter={(val) => format(new Date(val), "MMM d")}
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                  />
                  <YAxis 
                    stroke="hsl(var(--muted-foreground))" 
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(val) => `${val}%`}
                  />
                  <RechartsTooltip 
                    contentStyle={{ backgroundColor: "hsl(var(--card))", borderColor: "hsl(var(--border))" }}
                    labelFormatter={(val) => format(new Date(val), "MMM d, yyyy")}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="efficiencyPercent" 
                    stroke="hsl(var(--primary))" 
                    strokeWidth={3}
                    dot={{ r: 4, fill: "hsl(var(--primary))", strokeWidth: 0 }}
                    activeDot={{ r: 6, strokeWidth: 0 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Total Scans by Day</CardTitle>
              <CardDescription>Volume of waste categorized by citizens</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={efficiency || []} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="date" 
                    tickFormatter={(val) => format(new Date(val), "MMM d")}
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                  />
                  <YAxis 
                    stroke="hsl(var(--muted-foreground))" 
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                  />
                  <RechartsTooltip 
                    contentStyle={{ backgroundColor: "hsl(var(--card))", borderColor: "hsl(var(--border))" }}
                    labelFormatter={(val) => format(new Date(val), "MMM d, yyyy")}
                  />
                  <Bar dataKey="scansCount" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Mangaluru Waste Zones Heatmap</CardTitle>
            <CardDescription>Geographic distribution of scanning activity and hotspots</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Zone Name</TableHead>
                    <TableHead>Dominant Waste</TableHead>
                    <TableHead className="text-right">Total Scans</TableHead>
                    <TableHead className="text-right">Recyclable Count</TableHead>
                    <TableHead className="text-right">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {zones?.map((zone) => (
                    <TableRow key={zone.name}>
                      <TableCell className="font-medium">{zone.name}</TableCell>
                      <TableCell>{zone.dominantWasteType}</TableCell>
                      <TableCell className="text-right">{zone.totalScans.toLocaleString()}</TableCell>
                      <TableCell className="text-right">{zone.recyclableCount.toLocaleString()}</TableCell>
                      <TableCell className="text-right">
                        <Badge variant="outline" className={`capitalize border ${getHotspotColor(zone.hotspotLevel)}`}>
                          {zone.hotspotLevel}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                  {zones?.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-6 text-muted-foreground">
                        No zone data available.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
