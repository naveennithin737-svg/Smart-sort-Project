import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { 
  useListRewards, getListRewardsQueryKey,
  useRedeemReward,
  useGetMe, getGetMeQueryKey
} from "@workspace/api-client-react";
import { Layout } from "@/components/layout";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Coffee, ShoppingCart, Bus, Ticket, Loader2 } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";

export default function Rewards() {
  const { token } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  if (!token) {
    setLocation("/auth/login");
    return null;
  }

  const { data: user } = useGetMe({ 
    query: { enabled: !!token, queryKey: getGetMeQueryKey() } 
  });

  const { data: rewards, isLoading } = useListRewards({
    query: { queryKey: getListRewardsQueryKey() }
  });

  const redeemMutation = useRedeemReward();

  const [selectedReward, setSelectedReward] = useState<any>(null);
  const [filter, setFilter] = useState<string>("all");

  const handleRedeem = () => {
    if (!selectedReward || !user) return;

    redeemMutation.mutate({
      data: { userId: user.id }
    }, {
      onSuccess: (data) => {
        toast({
          title: "Reward Redeemed!",
          description: `Your voucher code is: ${data.voucherCode}`,
        });
        queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
        setSelectedReward(null);
      },
      onError: (err) => {
        toast({
          variant: "destructive",
          title: "Redemption Failed",
          description: err.message || "Not enough credits or reward unavailable.",
        });
        setSelectedReward(null);
      }
    });
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "cafe": return <Coffee className="w-4 h-4" />;
      case "grocery": return <ShoppingCart className="w-4 h-4" />;
      case "transport": return <Bus className="w-4 h-4" />;
      case "entertainment": return <Ticket className="w-4 h-4" />;
      default: return <Ticket className="w-4 h-4" />;
    }
  };

  const filteredRewards = filter === "all" 
    ? rewards 
    : rewards?.filter(r => r.category === filter);

  const categories = ["all", ...Array.from(new Set(rewards?.map(r => r.category) || []))];

  return (
    <Layout>
      <div className="container py-8 space-y-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Reward Marketplace</h1>
            <p className="text-muted-foreground mt-2">Spend your eco-credits at local Mangaluru businesses.</p>
          </div>
          <div className="bg-primary/10 text-primary px-4 py-2 rounded-lg font-semibold flex items-center gap-2">
            Balance: {user?.ecoCredits ?? 0} Credits
          </div>
        </div>

        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          {categories.map(cat => (
            <Button 
              key={cat} 
              variant={filter === cat ? "default" : "outline"}
              onClick={() => setFilter(cat)}
              className="capitalize whitespace-nowrap"
            >
              {cat}
            </Button>
          ))}
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filteredRewards?.map((reward) => (
              <Card key={reward.id} className="flex flex-col h-full border-border hover:border-primary/50 transition-colors">
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <Badge variant="secondary" className="capitalize gap-1">
                      {getCategoryIcon(reward.category)} {reward.category}
                    </Badge>
                    <Badge variant={reward.available ? "default" : "destructive"}>
                      {reward.available ? "Available" : "Sold Out"}
                    </Badge>
                  </div>
                  <CardTitle className="text-xl">{reward.title}</CardTitle>
                  <CardDescription className="font-medium text-foreground">{reward.partner}</CardDescription>
                </CardHeader>
                <CardContent className="flex-1">
                  <p className="text-sm text-muted-foreground">{reward.description}</p>
                  {reward.expiresAt && (
                    <p className="text-xs text-muted-foreground mt-4">
                      Expires: {new Date(reward.expiresAt).toLocaleDateString()}
                    </p>
                  )}
                </CardContent>
                <CardFooter className="pt-4 border-t border-border mt-auto">
                  <div className="flex w-full items-center justify-between gap-4">
                    <div className="font-bold text-primary">{reward.creditCost} <span className="text-xs font-normal text-muted-foreground">credits</span></div>
                    <Button 
                      disabled={!reward.available || (user?.ecoCredits ?? 0) < reward.creditCost}
                      onClick={() => setSelectedReward(reward)}
                    >
                      Redeem
                    </Button>
                  </div>
                </CardFooter>
              </Card>
            ))}
            {filteredRewards?.length === 0 && (
              <div className="col-span-full text-center py-12 text-muted-foreground">
                No rewards found for this category.
              </div>
            )}
          </div>
        )}

        <Dialog open={!!selectedReward} onOpenChange={(open) => !open && setSelectedReward(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Confirm Redemption</DialogTitle>
              <DialogDescription>
                You are about to spend {selectedReward?.creditCost} credits for "{selectedReward?.title}" at {selectedReward?.partner}.
              </DialogDescription>
            </DialogHeader>
            <div className="py-4">
              <div className="flex justify-between text-sm mb-2">
                <span>Current Balance:</span>
                <span className="font-medium">{user?.ecoCredits} credits</span>
              </div>
              <div className="flex justify-between text-sm mb-2">
                <span>Cost:</span>
                <span className="font-medium text-destructive">-{selectedReward?.creditCost} credits</span>
              </div>
              <div className="flex justify-between text-sm font-bold border-t pt-2 mt-2">
                <span>Remaining Balance:</span>
                <span>{(user?.ecoCredits ?? 0) - (selectedReward?.creditCost ?? 0)} credits</span>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setSelectedReward(null)}>Cancel</Button>
              <Button onClick={handleRedeem} disabled={redeemMutation.isPending}>
                {redeemMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Confirm Redemption
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
}
