import { useState, useRef } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useClassifyWaste, useSubmitFeedback } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import {
  Camera, Upload, RefreshCw, CheckCircle, AlertTriangle,
  Info, ThumbsUp, ThumbsDown, Loader2, Zap, MapPin,
  Cpu, Biohazard, Lightbulb, ScanLine
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const CATEGORY_COLORS: Record<string, string> = {
  "E-Waste": "bg-violet-500",
  "Plastic": "bg-blue-500",
  "Glass": "bg-cyan-500",
  "Metal": "bg-slate-500",
  "Paper": "bg-amber-500",
  "Organic": "bg-green-500",
  "Hazardous": "bg-red-500",
  "Mixed": "bg-gray-500",
};

const CATEGORY_ICONS: Record<string, React.ReactNode> = {
  "E-Waste": <Cpu className="w-5 h-5" />,
  "Hazardous": <Biohazard className="w-5 h-5" />,
};

type ClassificationResult = {
  scanId: number;
  category: string;
  subType: string;
  brand: string | null;
  model: string | null;
  hazardousComponents: string | null;
  disposalInstructions: string;
  recyclable: boolean;
  creditsEarned: number;
  confidence: number;
  tips: string[];
  zone: string;
};

export default function Scan() {
  const { token, userId } = useAuth();
  const { toast } = useToast();

  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [classification, setClassification] = useState<ClassificationResult | null>(null);
  const [feedbackGiven, setFeedbackGiven] = useState(false);
  const [streamActive, setStreamActive] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const classifyMutation = useClassifyWaste();
  const feedbackMutation = useSubmitFeedback();

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment", width: { ideal: 1280 }, height: { ideal: 720 } }
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setStreamActive(true);
      }
    } catch {
      toast({
        variant: "destructive",
        title: "Camera Error",
        description: "Could not access camera. Please allow camera permissions or try file upload.",
      });
    }
  };

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      (videoRef.current.srcObject as MediaStream).getTracks().forEach(t => t.stop());
      videoRef.current.srcObject = null;
      setStreamActive(false);
    }
  };

  const captureImage = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext("2d")?.drawImage(video, 0, 0);
    const dataUrl = canvas.toDataURL("image/jpeg", 0.85);
    setImageSrc(dataUrl);
    stopCamera();
    processImage(dataUrl.split(",")[1], "image/jpeg");
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const result = ev.target?.result as string;
      setImageSrc(result);
      processImage(result.split(",")[1], file.type);
    };
    reader.readAsDataURL(file);
  };

  const processImage = (base64: string, mime: string) => {
    setClassification(null);
    setFeedbackGiven(false);
    classifyMutation.mutate(
      { data: { imageBase64: base64, mimeType: mime, userId: userId ?? undefined } },
      {
        onSuccess: (data) => setClassification(data as ClassificationResult),
        onError: (err) => toast({
          variant: "destructive",
          title: "Classification Failed",
          description: (err as Error).message || "Something went wrong. Please try again.",
        }),
      }
    );
  };

  const resetScan = () => {
    setImageSrc(null);
    setClassification(null);
    setFeedbackGiven(false);
  };

  const handleFeedback = (correct: boolean) => {
    if (!classification?.scanId) return;
    feedbackMutation.mutate(
      { id: classification.scanId, data: { correct } },
      {
        onSuccess: () => {
          setFeedbackGiven(true);
          toast({ title: "Feedback recorded!", description: "Your feedback helps improve our AI model." });
        },
      }
    );
  };

  const barColor = CATEGORY_COLORS[classification?.category ?? ""] ?? "bg-primary";
  const isEwaste = classification?.category === "E-Waste";
  const isHazardous = classification?.category === "Hazardous" || (isEwaste && !classification?.recyclable);
  const confidencePct = Math.round((classification?.confidence ?? 0) * 100);

  return (
    <div className="container max-w-2xl py-8">
      <div className="flex flex-col gap-6">
        <div className="text-center">
          <h1 className="text-3xl font-bold tracking-tight text-primary">Scan Waste</h1>
          <p className="text-muted-foreground mt-2">
            Point at any item — AI will classify it and earn you Eco-Credits.
          </p>
        </div>

        {/* Camera / Upload Card */}
        <Card className="overflow-hidden border-2 border-primary/20 shadow-lg">
          <CardContent className="p-0">
            {!imageSrc ? (
              <div className="relative aspect-[4/3] sm:aspect-video bg-black flex items-center justify-center overflow-hidden">
                {streamActive ? (
                  <>
                    <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
                    {/* Animated scan line */}
                    <div className="absolute inset-0 pointer-events-none">
                      <motion.div
                        className="absolute left-4 right-4 h-0.5 bg-primary shadow-[0_0_8px_2px_rgba(16,185,129,0.7)]"
                        initial={{ top: "10%" }}
                        animate={{ top: "90%" }}
                        transition={{ duration: 2, repeat: Infinity, repeatType: "reverse", ease: "linear" }}
                      />
                      <div className="absolute inset-4 border-2 border-primary/40 rounded-xl">
                        <div className="absolute top-0 left-0 w-6 h-6 border-t-2 border-l-2 border-primary rounded-tl" />
                        <div className="absolute top-0 right-0 w-6 h-6 border-t-2 border-r-2 border-primary rounded-tr" />
                        <div className="absolute bottom-0 left-0 w-6 h-6 border-b-2 border-l-2 border-primary rounded-bl" />
                        <div className="absolute bottom-0 right-0 w-6 h-6 border-b-2 border-r-2 border-primary rounded-br" />
                      </div>
                    </div>
                    <div className="absolute bottom-6 left-0 right-0 flex justify-center items-center gap-4">
                      <Button
                        onClick={captureImage}
                        size="lg"
                        className="rounded-full h-16 w-16 p-0 shadow-xl border-4 border-white/50 bg-primary hover:bg-primary/90"
                      >
                        <ScanLine className="w-7 h-7" />
                      </Button>
                      <button
                        onClick={stopCamera}
                        className="absolute right-6 text-white/70 hover:text-white bg-black/30 rounded-full p-2"
                      >
                        <XIcon />
                      </button>
                    </div>
                  </>
                ) : (
                  <div className="p-8 flex flex-col items-center gap-5 text-center w-full">
                    <div className="relative">
                      <div className="p-5 rounded-full bg-primary/10 text-primary">
                        <Camera className="w-14 h-14" />
                      </div>
                      <motion.div
                        className="absolute inset-0 rounded-full border-2 border-primary/30"
                        animate={{ scale: [1, 1.3, 1], opacity: [0.7, 0, 0.7] }}
                        transition={{ duration: 2, repeat: Infinity }}
                      />
                    </div>
                    <div className="space-y-1">
                      <h3 className="font-semibold text-lg text-white">Ready to Scan</h3>
                      <p className="text-sm text-white/60">Use live camera or upload an image of any waste item</p>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-3 w-full max-w-xs">
                      <Button onClick={startCamera} className="w-full gap-2">
                        <Camera className="w-4 h-4" /> Live Camera
                      </Button>
                      <div className="relative w-full">
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleFileUpload}
                          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                        />
                        <Button variant="outline" className="w-full gap-2 bg-white/10 border-white/20 text-white hover:bg-white/20">
                          <Upload className="w-4 h-4" /> Upload Photo
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
                <canvas ref={canvasRef} className="hidden" />
              </div>
            ) : (
              <div className="relative aspect-[4/3] sm:aspect-video">
                <img src={imageSrc} alt="Scanned item" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />
                {classifyMutation.isPending && (
                  <div className="absolute inset-0 flex items-center justify-center bg-background/60 backdrop-blur-sm">
                    <div className="flex flex-col items-center gap-4 text-primary bg-card px-8 py-6 rounded-2xl shadow-2xl border border-primary/20">
                      <div className="relative">
                        <Loader2 className="w-12 h-12 animate-spin" />
                        <motion.div
                          className="absolute inset-0 rounded-full border-2 border-primary/20"
                          animate={{ scale: [1, 1.5, 1], opacity: [0.5, 0, 0.5] }}
                          transition={{ duration: 1.5, repeat: Infinity }}
                        />
                      </div>
                      <div className="text-center">
                        <p className="font-semibold">Analyzing with Gemini AI</p>
                        <p className="text-xs text-muted-foreground mt-1">Identifying waste type & hazards...</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Result Card */}
        <AnimatePresence>
          {classification && !classifyMutation.isPending && (
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ type: "spring", stiffness: 300, damping: 24 }}
            >
              <Card className="border-2 border-primary/20 shadow-xl overflow-hidden">
                <div className={`h-1.5 w-full ${barColor}`} />
                <CardContent className="p-6 space-y-5">
                  {/* Header */}
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg text-white ${barColor}`}>
                        {CATEGORY_ICONS[classification.category] ?? <Zap className="w-5 h-5" />}
                      </div>
                      <div>
                        <h2 className="text-2xl font-bold leading-tight">{classification.category}</h2>
                        <p className="text-muted-foreground text-sm">{classification.subType}</p>
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-2 shrink-0">
                      {classification.recyclable ? (
                        <Badge className="bg-green-100 text-green-700 dark:bg-green-950/40 dark:text-green-400 border-green-200 gap-1">
                          <CheckCircle className="w-3 h-3" /> Recyclable
                        </Badge>
                      ) : (
                        <Badge className="bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400 border-amber-200 gap-1">
                          <AlertTriangle className="w-3 h-3" /> Non-Recyclable
                        </Badge>
                      )}
                      <span className="text-xs text-muted-foreground">{confidencePct}% confidence</span>
                    </div>
                  </div>

                  {/* E-Waste Specific Panel */}
                  {isEwaste && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      className="rounded-xl border border-violet-200 dark:border-violet-800/40 bg-violet-50 dark:bg-violet-950/20 overflow-hidden"
                    >
                      <div className="flex items-center gap-2 px-4 py-3 bg-violet-100 dark:bg-violet-900/30 border-b border-violet-200 dark:border-violet-800/40">
                        <Cpu className="w-4 h-4 text-violet-600" />
                        <span className="font-semibold text-sm text-violet-700 dark:text-violet-300">E-Waste Details</span>
                        <Badge className="ml-auto bg-violet-600 text-white text-xs">Tracked</Badge>
                      </div>
                      <div className="p-4 space-y-3 text-sm">
                        {(classification.brand || classification.model) && (
                          <div className="flex flex-wrap gap-x-6 gap-y-1">
                            {classification.brand && (
                              <div>
                                <span className="text-muted-foreground">Brand: </span>
                                <span className="font-medium">{classification.brand}</span>
                              </div>
                            )}
                            {classification.model && (
                              <div>
                                <span className="text-muted-foreground">Model: </span>
                                <span className="font-medium">{classification.model}</span>
                              </div>
                            )}
                          </div>
                        )}
                        {classification.hazardousComponents && (
                          <div className="flex items-start gap-2 p-3 bg-red-50 dark:bg-red-950/20 rounded-lg border border-red-200 dark:border-red-800/30">
                            <Biohazard className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                            <div>
                              <p className="font-medium text-red-700 dark:text-red-400 text-xs uppercase tracking-wide mb-1">Hazardous Materials</p>
                              <p className="text-foreground/80">{classification.hazardousComponents}</p>
                            </div>
                          </div>
                        )}
                        <div className="flex items-center gap-2 text-muted-foreground text-xs">
                          <MapPin className="w-3.5 h-3.5 shrink-0" />
                          <span>Zone: <span className="font-medium text-foreground">{classification.zone}, Mangaluru</span></span>
                        </div>
                      </div>
                    </motion.div>
                  )}

                  {/* Disposal Instructions */}
                  <div className="bg-muted/60 rounded-xl p-4">
                    <div className="flex items-start gap-3">
                      <Info className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                      <div>
                        <h4 className="font-semibold mb-1 text-sm">Disposal Instructions</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">{classification.disposalInstructions}</p>
                      </div>
                    </div>
                  </div>

                  {/* Zone Badge (non-ewaste) */}
                  {!isEwaste && classification.zone && (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <MapPin className="w-4 h-4" />
                      <span>Logged in <span className="font-medium text-foreground">{classification.zone}</span> zone</span>
                    </div>
                  )}

                  {/* Credits Earned */}
                  {token && classification.creditsEarned > 0 && (
                    <motion.div
                      initial={{ scale: 0.9, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      transition={{ delay: 0.2 }}
                      className="flex items-center justify-between p-4 bg-primary/10 text-primary rounded-xl"
                    >
                      <div>
                        <div className="font-semibold text-sm">Eco-Credits Earned!</div>
                        <div className="text-xs text-primary/70">Added to your Green Balance</div>
                      </div>
                      <div className="text-3xl font-extrabold">+{classification.creditsEarned}</div>
                    </motion.div>
                  )}

                  {/* Tips */}
                  {classification.tips && classification.tips.length > 0 && (
                    <div className="space-y-2">
                      <h4 className="font-semibold text-sm flex items-center gap-2">
                        <Lightbulb className="w-4 h-4 text-amber-500" /> Tips
                      </h4>
                      <div className="grid gap-2">
                        {classification.tips.map((tip, i) => (
                          <div key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                            <span className="text-primary font-bold shrink-0 mt-0.5">•</span>
                            <span>{tip}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="flex flex-col sm:flex-row gap-3 pt-2">
                    <Button onClick={resetScan} variant="outline" className="flex-1 gap-2">
                      <RefreshCw className="w-4 h-4" /> Scan Another
                    </Button>
                    {isEwaste && (
                      <Link href="/ewaste" className="flex-1">
                        <Button variant="secondary" className="w-full gap-2">
                          <Cpu className="w-4 h-4" /> View E-Waste Data
                        </Button>
                      </Link>
                    )}
                    {token && (
                      <Link href="/rewards" className="flex-1">
                        <Button className="w-full gap-2">View Rewards</Button>
                      </Link>
                    )}
                  </div>

                  {/* AI Feedback */}
                  {classification.scanId && !feedbackGiven && (
                    <div className="pt-4 border-t flex flex-col items-center gap-3">
                      <p className="text-xs text-muted-foreground text-center">Was this AI classification correct?</p>
                      <div className="flex gap-3">
                        <Button
                          variant="outline"
                          size="sm"
                          className="gap-2 text-green-600 hover:bg-green-50 border-green-200"
                          onClick={() => handleFeedback(true)}
                          disabled={feedbackMutation.isPending}
                        >
                          <ThumbsUp className="w-3.5 h-3.5" /> Yes, correct
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="gap-2 text-destructive hover:bg-destructive/10 border-destructive/30"
                          onClick={() => handleFeedback(false)}
                          disabled={feedbackMutation.isPending}
                        >
                          <ThumbsDown className="w-3.5 h-3.5" /> No, incorrect
                        </Button>
                      </div>
                    </div>
                  )}
                  {feedbackGiven && (
                    <div className="pt-4 border-t text-center text-sm text-muted-foreground flex items-center justify-center gap-2">
                      <CheckCircle className="w-4 h-4 text-green-500" />
                      Thank you! Your feedback improves our AI model.
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {!token && (
          <Card className="bg-primary/5 border-primary/20">
            <CardContent className="p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
              <p className="text-sm text-muted-foreground">Sign in to earn Eco-Credits for every scan.</p>
              <div className="flex gap-2 shrink-0">
                <Link href="/auth/login">
                  <Button variant="outline" size="sm">Login</Button>
                </Link>
                <Link href="/auth/register">
                  <Button size="sm">Create Account</Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

function XIcon() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M18 6 6 18" /><path d="m6 6 12 12" />
    </svg>
  );
}
