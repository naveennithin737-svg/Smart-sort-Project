import { useGetLeaderboard, getGetLeaderboardQueryKey } from "@workspace/api-client-react";
import { Layout } from "@/components/layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Trophy, Medal, Crown } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";
import { Loader2 } from "lucide-react";

export default function Leaderboard() {
  const { token } = useAuth();
  
  const { data: user } = useGetMe({ 
    query: { enabled: !!token, queryKey: getGetMeQueryKey() } 
  });

  const { data: leaderboard, isLoading } = useGetLeaderboard(
    { limit: 100 },
    { query: { queryKey: getGetLeaderboardQueryKey({ limit: 100 }) } }
  );

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Crown className="w-5 h-5 text-yellow-500" />;
      case 2: return <Medal className="w-5 h-5 text-gray-400" />;
      case 3: return <Medal className="w-5 h-5 text-amber-600" />;
      default: return <span className="font-bold text-muted-foreground w-5 text-center">{rank}</span>;
    }
  };

  return (
    <Layout>
      <div className="container max-w-4xl py-8 space-y-8">
        <div className="text-center space-y-4">
          <div className="mx-auto w-16 h-16 bg-primary/10 text-primary rounded-full flex items-center justify-center mb-4">
            <Trophy className="w-8 h-8" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight">Global Leaderboard</h1>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Mangaluru's top eco-heroes. Sort smart to climb the ranks.
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Top Recyclers</CardTitle>
            <CardDescription>Ranked by total eco-credits earned</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : (
              <div className="divide-y border rounded-lg overflow-hidden">
                {leaderboard?.map((entry) => {
                  const isCurrentUser = user?.id === entry.userId;
                  return (
                    <div 
                      key={entry.userId} 
                      className={`flex items-center justify-between p-4 transition-colors ${
                        isCurrentUser ? 'bg-primary/5 border-l-4 border-l-primary' : 'hover:bg-muted/50 border-l-4 border-l-transparent'
                      }`}
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-8 flex justify-center shrink-0">
                          {getRankIcon(entry.rank)}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className={`font-semibold ${isCurrentUser ? 'text-primary' : ''}`}>
                              {entry.name} {isCurrentUser && "(You)"}
                            </span>
                          </div>
                          <div className="text-sm text-muted-foreground flex items-center gap-2">
                            <span className="bg-muted px-2 py-0.5 rounded text-xs">{entry.badge}</span>
                            <span>•</span>
                            <span>{entry.totalScans} scans</span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-primary">{entry.ecoCredits.toLocaleString()}</div>
                        <div className="text-xs text-muted-foreground">credits</div>
                      </div>
                    </div>
                  );
                })}
                {leaderboard?.length === 0 && (
                  <div className="p-8 text-center text-muted-foreground">
                    No entries yet. Be the first to scan!
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
