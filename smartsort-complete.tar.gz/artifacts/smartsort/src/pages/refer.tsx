import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { 
  useGetMe, getGetMeQueryKey,
  useGetMyReferralCode, getGetMyReferralCodeQueryKey
} from "@workspace/api-client-react";
import { Layout } from "@/components/layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Copy, Users, Check, Gift } from "lucide-react";
import { useState } from "react";
import { Loader2 } from "lucide-react";

export default function Refer() {
  const { token } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);

  if (!token) {
    setLocation("/auth/login");
    return null;
  }

  const { data: user } = useGetMe({ 
    query: { enabled: !!token, queryKey: getGetMeQueryKey() } 
  });

  const { data: referralData, isLoading } = useGetMyReferralCode(
    { userId: user?.id as number },
    { query: { enabled: !!user?.id, queryKey: getGetMyReferralCodeQueryKey({ userId: user?.id as number }) } }
  );

  const handleCopy = () => {
    if (referralData?.referralUrl) {
      navigator.clipboard.writeText(referralData.referralUrl);
      setCopied(true);
      toast({
        title: "Copied to clipboard!",
        description: "Share this link with your friends to earn bonus credits.",
      });
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <Layout>
      <div className="container max-w-3xl py-8 space-y-8">
        <div className="text-center space-y-4 mb-8">
          <div className="mx-auto w-16 h-16 bg-primary/10 text-primary rounded-full flex items-center justify-center mb-4">
            <Users className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-bold tracking-tight">Refer & Earn</h1>
          <p className="text-xl text-muted-foreground max-w-xl mx-auto">
            Invite your friends to join SmartSort. You both get 50 bonus eco-credits when they sign up!
          </p>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="grid gap-8">
            <Card className="border-primary/20 bg-primary/5">
              <CardHeader className="text-center pb-2">
                <CardTitle>Your Unique Invite Link</CardTitle>
                <CardDescription>Share this link anywhere</CardDescription>
              </CardHeader>
              <CardContent className="flex flex-col items-center gap-4">
                <div className="flex items-center gap-2 w-full max-w-md bg-background p-2 rounded-lg border border-border">
                  <div className="flex-1 truncate font-mono text-sm px-2 text-muted-foreground">
                    {referralData?.referralUrl || "Generating..."}
                  </div>
                  <Button onClick={handleCopy} className="shrink-0 gap-2">
                    {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    {copied ? "Copied" : "Copy"}
                  </Button>
                </div>
                <div className="text-sm font-medium flex items-center gap-2">
                  <span className="text-muted-foreground">Your code:</span> 
                  <span className="text-primary text-lg tracking-widest">{referralData?.code}</span>
                </div>
              </CardContent>
            </Card>

            <div className="grid sm:grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <Users className="w-4 h-4" />
                    Total Referrals
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-4xl font-bold">{referralData?.totalReferrals ?? 0}</div>
                  <p className="text-sm text-muted-foreground mt-1">Friends joined</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <Gift className="w-4 h-4" />
                    Credits Earned
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-4xl font-bold text-primary">+{referralData?.creditsEarned ?? 0}</div>
                  <p className="text-sm text-muted-foreground mt-1">From referrals</p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>How it works</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-4">
                  <div className="w-8 h-8 rounded-full bg-primary/20 text-primary flex items-center justify-center font-bold shrink-0">1</div>
                  <div>
                    <h4 className="font-semibold">Share your link</h4>
                    <p className="text-sm text-muted-foreground">Send your unique link or code to friends and family in Mangaluru.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="w-8 h-8 rounded-full bg-primary/20 text-primary flex items-center justify-center font-bold shrink-0">2</div>
                  <div>
                    <h4 className="font-semibold">They sign up</h4>
                    <p className="text-sm text-muted-foreground">Your friends create a new SmartSort account using your link.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="w-8 h-8 rounded-full bg-primary/20 text-primary flex items-center justify-center font-bold shrink-0">3</div>
                  <div>
                    <h4 className="font-semibold">Both get rewarded</h4>
                    <p className="text-sm text-muted-foreground">You both instantly receive 50 eco-credits in your accounts!</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </Layout>
  );
}
