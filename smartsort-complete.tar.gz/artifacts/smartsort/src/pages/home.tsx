import { useEffect, useState } from "react";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScanLine, Trophy, ArrowRight, Leaf, Recycle, Globe, Play, Quote } from "lucide-react";
import { useGetCommunityStats, getGetCommunityStatsQueryKey, useGetLeaderboard, getGetLeaderboardQueryKey } from "@workspace/api-client-react";
import { motion, AnimatePresence } from "framer-motion";

const ECO_QUOTES = [
  { text: "We do not inherit the earth from our ancestors — we borrow it from our children.", author: "Native American Proverb" },
  { text: "The greatest threat to our planet is the belief that someone else will save it.", author: "Robert Swan" },
  { text: "Small acts, when multiplied by millions of people, can transform the world.", author: "Howard Zinn" },
  { text: "What we are doing to the forests of the world is but a mirror reflection of what we are doing to ourselves.", author: "Mahatma Gandhi" },
  { text: "In every walk with nature, one receives far more than he seeks.", author: "John Muir" },
];

export default function Home() {
  const { token } = useAuth();
  const [showTutorial, setShowTutorial] = useState(false);
  const [quoteIndex, setQuoteIndex] = useState(0);

  const { data: stats } = useGetCommunityStats({
    query: { queryKey: getGetCommunityStatsQueryKey() }
  });

  const { data: leaderboard } = useGetLeaderboard({ limit: 5 }, {
    query: { queryKey: getGetLeaderboardQueryKey({ limit: 5 }) }
  });

  useEffect(() => {
    const hasSeenTutorial = localStorage.getItem("smartsort_tutorial");
    if (!hasSeenTutorial && !token) setShowTutorial(true);
  }, [token]);

  useEffect(() => {
    const interval = setInterval(() => {
      setQuoteIndex(i => (i + 1) % ECO_QUOTES.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const closeTutorial = () => {
    localStorage.setItem("smartsort_tutorial", "true");
    setShowTutorial(false);
  };

  const currentQuote = ECO_QUOTES[quoteIndex];

  return (
    <div className="flex flex-col min-h-screen">

      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-background to-emerald-50/30 dark:to-emerald-950/10 py-20 sm:py-32">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-primary/5 via-transparent to-transparent pointer-events-none" />
        <div className="container relative z-10 px-4 md:px-6">
          <div className="grid gap-12 lg:grid-cols-2 lg:gap-8 items-center">
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="flex flex-col justify-center space-y-8"
            >
              {/* Rotating Quote Badge */}
              <div className="overflow-hidden min-h-[52px]">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={quoteIndex}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -12 }}
                    transition={{ duration: 0.4 }}
                    className="flex items-start gap-2 text-sm text-primary/80 bg-primary/8 rounded-lg px-3 py-2 border border-primary/15"
                  >
                    <Quote className="h-4 w-4 shrink-0 mt-0.5 text-primary" />
                    <span className="italic leading-snug">
                      "{currentQuote.text}"
                      <span className="not-italic font-medium text-primary/60 ml-1">— {currentQuote.author}</span>
                    </span>
                  </motion.div>
                </AnimatePresence>
              </div>

              <div className="space-y-4">
                <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl xl:text-6xl text-foreground">
                  Sort Smart. <br />
                  <span className="text-primary">Earn Rewards.</span>
                </h1>
                <p className="max-w-[600px] text-lg text-muted-foreground sm:text-xl leading-relaxed">
                  Scan any waste item with Gemini AI, get instant disposal instructions, and earn eco-credits for local discounts — all while making your city greener.
                </p>
              </div>

              <div className="flex flex-col gap-3 min-[400px]:flex-row">
                <Link href="/scan">
                  <Button size="lg" className="w-full gap-2 h-14 text-lg shadow-lg shadow-primary/20">
                    <ScanLine className="h-5 w-5" />
                    Scan Your Waste
                  </Button>
                </Link>
                {!token && (
                  <Link href="/auth/register">
                    <Button size="lg" variant="outline" className="w-full gap-2 h-14 text-lg bg-background">
                      Join the Movement
                      <ArrowRight className="h-5 w-5" />
                    </Button>
                  </Link>
                )}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="relative mx-auto w-full max-w-[460px] lg:max-w-none"
            >
              <div className="aspect-square rounded-3xl overflow-hidden border-2 border-primary/20 bg-muted relative shadow-2xl shadow-primary/10">
                <div className="absolute inset-0 bg-gradient-to-tr from-primary/15 via-transparent to-transparent z-10" />
                <div className="absolute inset-0 flex items-center justify-center p-6">
                  <div className="flex flex-col items-center justify-center p-8 text-center bg-card/90 backdrop-blur-md rounded-2xl border border-border shadow-xl w-full">
                    <div className="relative mb-5">
                      <div className="p-4 rounded-full bg-primary/10">
                        <ScanLine className="h-14 w-14 text-primary" />
                      </div>
                      <motion.div
                        className="absolute inset-0 rounded-full border-2 border-primary/30"
                        animate={{ scale: [1, 1.4, 1], opacity: [0.6, 0, 0.6] }}
                        transition={{ duration: 2.5, repeat: Infinity }}
                      />
                    </div>
                    <h3 className="text-xl font-bold mb-2">AI Classification</h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Gemini AI instantly identifies your waste and tells you exactly how to dispose of it.
                    </p>
                    <div className="mt-4 flex gap-2 flex-wrap justify-center">
                      {["Plastic", "E-Waste", "Organic", "Metal"].map(tag => (
                        <span key={tag} className="px-2.5 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Quote Strip */}
      <div className="bg-primary py-4 overflow-hidden">
        <motion.div
          className="flex gap-16 whitespace-nowrap"
          animate={{ x: ["0%", "-50%"] }}
          transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
        >
          {[...ECO_QUOTES, ...ECO_QUOTES].map((q, i) => (
            <span key={i} className="text-primary-foreground/90 text-sm font-medium shrink-0">
              ✦ {q.text}
            </span>
          ))}
        </motion.div>
      </div>

      {/* Community Impact */}
      <section className="py-16 md:py-24 bg-background">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
            <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary">
              <Globe className="h-3.5 w-3.5" /> Live Community Impact
            </div>
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Together We're Making a Difference</h2>
            <p className="max-w-[700px] text-muted-foreground md:text-lg">
              Every scan counts. Here's what our community has achieved so far.
            </p>
          </div>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { label: "Total Scans", value: stats?.totalScans?.toLocaleString() ?? "…", icon: ScanLine },
              { label: "CO₂ Saved (kg)", value: stats?.co2SavedKg?.toLocaleString() ?? "…", icon: Globe },
              { label: "Plastic Diverted (kg)", value: stats?.plasticDivertedKg?.toLocaleString() ?? "…", icon: Recycle },
              { label: "Active Users", value: stats?.totalUsersActive?.toLocaleString() ?? "…", icon: Trophy },
            ].map(({ label, value, icon: Icon }, i) => (
              <motion.div
                key={label}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
              >
                <Card className="bg-primary/5 border-primary/20 hover:border-primary/40 transition-colors">
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">{label}</CardTitle>
                    <Icon className="h-4 w-4 text-primary" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-foreground">{value}</div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Leaderboard + How It Works */}
      <section className="py-16 md:py-24 bg-muted/40 border-t border-border">
        <div className="container px-4 md:px-6">
          <div className="grid gap-12 lg:grid-cols-2">
            <div>
              <h2 className="text-3xl font-bold tracking-tight mb-6">Top Eco-Heroes</h2>
              <Card className="overflow-hidden">
                <CardContent className="p-0">
                  <div className="divide-y divide-border">
                    {leaderboard?.map((entry, i) => (
                      <motion.div
                        key={entry.userId}
                        initial={{ opacity: 0, x: -8 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: i * 0.05 }}
                        className="flex items-center justify-between p-4 hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center gap-4">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${
                            i === 0 ? "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30" :
                            i === 1 ? "bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-200" :
                            i === 2 ? "bg-orange-100 text-orange-700 dark:bg-orange-900/30" :
                            "bg-primary/10 text-primary"
                          }`}>
                            {i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : entry.rank}
                          </div>
                          <div>
                            <div className="font-semibold">{entry.name}</div>
                            <div className="text-xs text-muted-foreground">{entry.badge}</div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-bold text-primary">{entry.ecoCredits.toLocaleString()}</div>
                          <div className="text-xs text-muted-foreground">credits</div>
                        </div>
                      </motion.div>
                    ))}
                    {!leaderboard && (
                      <div className="p-8 text-center text-muted-foreground text-sm">Loading leaderboard…</div>
                    )}
                  </div>
                </CardContent>
              </Card>
              <div className="mt-5 text-center">
                <Link href="/leaderboard">
                  <Button variant="outline" className="gap-2">
                    View Full Leaderboard <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </div>

            <div className="flex flex-col justify-center space-y-8">
              <h2 className="text-3xl font-bold tracking-tight">How It Works</h2>
              <div className="space-y-6">
                {[
                  { n: "1", title: "Scan", desc: "Point your camera at any waste item. Our AI instantly identifies it and its sub-type." },
                  { n: "2", title: "Sort", desc: "Follow clear, actionable instructions on which bin or facility to use for correct disposal." },
                  { n: "3", title: "Earn", desc: "Collect eco-credits for every correct scan and redeem them for local rewards." },
                ].map(({ n, title, desc }) => (
                  <motion.div
                    key={n}
                    initial={{ opacity: 0, x: 16 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    className="flex gap-4"
                  >
                    <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary/15 flex items-center justify-center text-primary font-bold text-xl border border-primary/20">
                      {n}
                    </div>
                    <div>
                      <h3 className="text-xl font-bold mb-1">{title}</h3>
                      <p className="text-muted-foreground leading-relaxed">{desc}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
              <Link href="/scan">
                <Button size="lg" className="w-full sm:w-auto gap-2 mt-2">
                  <ScanLine className="h-5 w-5" /> Start Scanning Now
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Tutorial Dialog */}
      <Dialog open={showTutorial} onOpenChange={setShowTutorial}>
        <DialogContent className="sm:max-w-md text-center">
          <DialogHeader>
            <div className="mx-auto w-16 h-16 bg-primary/10 text-primary rounded-full flex items-center justify-center mb-4">
              <Leaf className="w-8 h-8" />
            </div>
            <DialogTitle className="text-2xl font-bold text-center">Welcome to SmartSort!</DialogTitle>
            <DialogDescription className="text-center text-base pt-2">
              Ready to earn rewards and help the planet? Here's how it works:
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4 text-left">
            <div className="flex items-start gap-3">
              <ScanLine className="w-5 h-5 text-primary mt-0.5 shrink-0" />
              <p className="text-sm"><strong>Scan waste</strong> before throwing it away to get AI classification.</p>
            </div>
            <div className="flex items-start gap-3">
              <Trophy className="w-5 h-5 text-primary mt-0.5 shrink-0" />
              <p className="text-sm"><strong>Earn Eco-Credits</strong> for correct sorting and grow your rank.</p>
            </div>
            <div className="flex items-start gap-3">
              <GiftIcon className="w-5 h-5 text-primary mt-0.5 shrink-0" />
              <p className="text-sm"><strong>Redeem rewards</strong> at local cafes, stores, and more.</p>
            </div>
          </div>
          <div className="flex flex-col gap-2 mt-2">
            <Button onClick={closeTutorial} className="w-full gap-2 h-11">
              <Play className="w-4 h-4" /> Start Scanning
            </Button>
            <Link href="/auth/register">
              <Button variant="outline" className="w-full h-11" onClick={closeTutorial}>
                Create an Account
              </Button>
            </Link>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function GiftIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="8" width="18" height="4" rx="1" />
      <path d="M12 8v13" />
      <path d="M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7" />
      <path d="M7.5 8a2.5 2.5 0 0 1 0-5A4.8 8 0 0 1 12 8a4.8 8 0 0 1 4.5-5 2.5 2.5 0 0 1 0 5" />
    </svg>
  );
}
