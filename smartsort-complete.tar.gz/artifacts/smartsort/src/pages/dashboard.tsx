import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { 
  useGetMe, getGetMeQueryKey, 
  useGetUserLevel, getGetUserLevelQueryKey,
  useListTransactions, getListTransactionsQueryKey,
  useListScans, getListScansQueryKey
} from "@workspace/api-client-react";
import { Layout } from "@/components/layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScanLine, Gift, Award, TrendingUp, Clock, AlertCircle } from "lucide-react";
import { Link } from "wouter";
import { format } from "date-fns";

export default function Dashboard() {
  const { token } = useAuth();
  const [, setLocation] = useLocation();

  if (!token) {
    setLocation("/auth/login");
    return null;
  }

  const { data: user } = useGetMe({ 
    query: { enabled: !!token, queryKey: getGetMeQueryKey() } 
  });

  const { data: userLevel } = useGetUserLevel(
    user?.id as number, 
    { query: { enabled: !!user?.id, queryKey: getGetUserLevelQueryKey(user?.id as number) } }
  );

  const { data: transactions } = useListTransactions(
    user?.id as number,
    { limit: 5 },
    { query: { enabled: !!user?.id, queryKey: getListTransactionsQueryKey(user?.id as number, { limit: 5 }) } }
  );

  const { data: scans } = useListScans(
    { userId: user?.id, limit: 5 },
    { query: { enabled: !!user?.id, queryKey: getListScansQueryKey({ userId: user?.id, limit: 5 }) } }
  );

  return (
    <Layout>
      <div className="container py-8 space-y-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground mt-2">Welcome back, {user?.name}</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {/* Credits Card */}
          <Card className="bg-primary/10 border-primary/20 relative overflow-hidden">
            <div className="absolute top-0 right-0 -mt-4 -mr-4 w-24 h-24 bg-primary/20 rounded-full blur-2xl pointer-events-none" />
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Eco-Credits Balance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold text-primary">{user?.ecoCredits?.toLocaleString() ?? 0}</div>
              <p className="text-xs text-muted-foreground mt-1">Available to spend</p>
              <div className="mt-4 flex gap-2">
                <Link href="/scan" className="flex-1">
                  <Button size="sm" className="w-full gap-2"><ScanLine className="w-4 h-4" /> Earn</Button>
                </Link>
                <Link href="/rewards" className="flex-1">
                  <Button size="sm" variant="outline" className="w-full gap-2 bg-background"><Gift className="w-4 h-4" /> Redeem</Button>
                </Link>
              </div>
            </CardContent>
          </Card>

          {/* Level Card */}
          <Card className="lg:col-span-2">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2">
                <Award className="w-5 h-5 text-primary" />
                Your Impact Level
              </CardTitle>
            </CardHeader>
            <CardContent>
              {userLevel ? (
                <div className="space-y-4">
                  <div className="flex justify-between items-end">
                    <div>
                      <div className="text-2xl font-bold">{userLevel.badge}</div>
                      <div className="text-sm text-muted-foreground">Level {userLevel.level}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium">Rank #{userLevel.rank}</div>
                      <div className="text-xs text-muted-foreground">{userLevel.totalScans} total scans</div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs">
                      <span className="text-muted-foreground">Progress to next level</span>
                      <span className="font-medium">{userLevel.currentCredits} / {userLevel.creditsForNextLevel}</span>
                    </div>
                    <Progress value={userLevel.progressPercent} className="h-2" />
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-center h-[120px] text-muted-foreground">
                  Loading level data...
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          {/* Recent Scans */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div>
                <CardTitle>Recent Scans</CardTitle>
                <CardDescription>Your latest AI classifications</CardDescription>
              </div>
              <ScanLine className="w-5 h-5 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {scans?.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground flex flex-col items-center gap-2">
                    <AlertCircle className="w-8 h-8 opacity-20" />
                    <p>No scans yet. Start scanning to earn credits!</p>
                  </div>
                ) : (
                  scans?.map((scan) => (
                    <div key={scan.id} className="flex items-center justify-between p-3 rounded-lg border bg-card">
                      <div className="flex items-center gap-3">
                        <div className={`w-2 h-10 rounded-full ${scan.recyclable ? 'bg-green-500' : 'bg-amber-500'}`} />
                        <div>
                          <p className="font-medium">{scan.category}</p>
                          <p className="text-xs text-muted-foreground">{scan.subType} • {format(new Date(scan.createdAt), "MMM d, h:mm a")}</p>
                        </div>
                      </div>
                      {scan.creditsEarned > 0 && (
                        <Badge variant="secondary" className="bg-primary/10 text-primary hover:bg-primary/20">
                          +{scan.creditsEarned}
                        </Badge>
                      )}
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Recent Transactions */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div>
                <CardTitle>Ledger</CardTitle>
                <CardDescription>Recent credit activity</CardDescription>
              </div>
              <TrendingUp className="w-5 h-5 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {transactions?.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground flex flex-col items-center gap-2">
                    <Clock className="w-8 h-8 opacity-20" />
                    <p>No transactions yet.</p>
                  </div>
                ) : (
                  transactions?.map((tx) => (
                    <div key={tx.id} className="flex items-center justify-between p-3 border-b last:border-0">
                      <div>
                        <p className="font-medium text-sm">{tx.description}</p>
                        <p className="text-xs text-muted-foreground">{format(new Date(tx.createdAt), "MMM d, yyyy")}</p>
                      </div>
                      <div className={`font-bold ${tx.amount > 0 ? 'text-primary' : 'text-foreground'}`}>
                        {tx.amount > 0 ? '+' : ''}{tx.amount}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
