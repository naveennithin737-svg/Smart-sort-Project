# SmartSort: AI Waste Intelligence

A full-stack gamified sustainability web app for Mangaluru, India.

## Architecture

**Monorepo** managed with pnpm workspaces.

### Services
- `artifacts/smartsort` — React + Vite frontend (previewPath: `/`)
- `artifacts/api-server` — Express 5 + Node.js API server (paths: `/api`)
- `lib/db` — Drizzle ORM schema + PostgreSQL client
- `lib/api-spec` — OpenAPI spec + Orval codegen
- `lib/api-zod` — Zod schemas generated from OpenAPI
- `lib/api-client-react` — React Query hooks generated from OpenAPI
- `lib/integrations-gemini-ai` — Gemini AI client via Replit AI Integrations

### Key Environment Variables
- `DATABASE_URL` — PostgreSQL connection string
- `SESSION_SECRET` — JWT signing secret
- `AI_INTEGRATIONS_GEMINI_BASE_URL` + `AI_INTEGRATIONS_GEMINI_API_KEY` — Gemini via Replit proxy

## Features

1. **Gemini Vision AI Classifier** — Upload/capture waste image → Gemini 2.5 Flash classifies category, sub-type, recyclability, disposal instructions, tips
2. **Eco-Credits Ledger** — Credits earned per scan (10–20 base + confidence bonus); stored in `transactions` table
3. **Reward Marketplace** — 8 seeded Mangaluru-local rewards (Ideal Coffee, Shree Sagar, Big Bazaar, KSRTC bus pass, PVR, etc.)
4. **Refer & Earn** — Unique referral codes; 50 credits to both parties on referee's first scan
5. **Global Leaderboard** — Ranked by eco_credits with badge system (Eco-Novice → Planet Champion)
6. **User Leveling** — 6 levels based on credits (0/100/300/600/1200/2500 thresholds)
7. **Municipal Analytics Portal** — Admin role with waste heatmap of Mangaluru zones (Kadri, Bejai, Mangaladevi, Balmatta, Pandeshwar, Kankanady, Attavar)
8. **AI Feedback Loop** — Users can flag incorrect classifications with correct category

## Database Schema

Tables: `users`, `scans`, `transactions`, `rewards`, `vouchers`, `referrals`, `conversations`, `messages`

## Demo Accounts

All demo passwords: `demo1234`
- `priya@demo.com` — 850 credits, Waste Warrior
- `kavitha@demo.com` — 1250 credits, Eco-Hero  
- `deepa@demo.com` — 2100 credits, Planet Champion
- `admin@smartsort.gov` — Admin (municipal analytics portal access)

Admin credentials: `admin@smartsort.gov` / `demo1234`

## API Routes

- `POST /api/auth/register` — Register new user
- `POST /api/auth/login` — Login → JWT token
- `POST /api/classify` — Gemini Vision waste classification
- `GET /api/scans` — List scans (filterable by userId)
- `POST /api/scans/:id/feedback` — Submit AI feedback
- `GET /api/users/:id` — User profile
- `GET /api/users/:id/transactions` — Credit history
- `GET /api/rewards` — List available rewards
- `POST /api/rewards/:id/redeem` — Redeem reward for voucher
- `GET /api/referrals/:userId` — Referral stats
- `GET /api/leaderboard` — Global leaderboard
- `GET /api/community/stats` — Community impact stats
- `GET /api/admin/analytics` — Municipal analytics (admin only)
- `GET /api/admin/zones` — Zone waste heatmap data (admin only)
- `GET /api/admin/efficiency` — Collection efficiency metrics (admin only)
